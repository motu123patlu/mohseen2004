s=input().split()
c=0
for i in s:
    c=c+1
print(c-1)